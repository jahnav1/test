1. Unzip wfreerdp.zip
2. Run wfreerdp.exe from command line:
 wfreerdp.exe /v:<machine_ip_or_name> /w:<resolution_width> /h:<resolution_height> /bpp:<resolution_depth> /u:<user_name> /p:<password>

Sample:

wfreerdp.exe /v:TestMachine /u:machine\localuser /p:abcd1234
